/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maciejmainproject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 *
 * @author macie
 */
public class MaciejMainProject extends Application {

    private int n = 0;
    private int guessGameCount = 1;
    private int noOfLines = 0;
    private String finalUserName;
    private String topuser1;
    private int topguess1;
    private int topscore1;
    private String searchUsername;
    private int searchScore;
    private int searchGuess;

    @Override
    public void start(Stage primaryStage) {

         Stage window = primaryStage;
        
        //welcome page objects
        Text welcometext = new Text();
        welcometext.setText("Welcome to Guess The Number Game!");//sets the String for the text
        welcometext.setFont(Font.font("Verdana", 40));//changes the font to verdana and makes the font size 40
        welcometext.setFill(Color.RED);//changes colour to red

        Button loginbutton = new Button();
        loginbutton.setText("Log in");//button text
        loginbutton.setTranslateY(270);//allows to translate the object from it's initial position
        loginbutton.setMinSize(200, 100);//sets minimum size for the button box

        //login page objects
        Text loginText = new Text();
        loginText.setText("Welcome to Login Window");
        loginText.setTranslateY(-50);
        loginText.setFont(Font.font("Verdana", 35));

        Text loginText2 = new Text();
        loginText2.setText("Please log in or press the register button");

        Label loginLabel = new Label("Username");//label is similar to text, it displays a text in the scene
        loginLabel.setTranslateY(100);
        loginLabel.setTranslateX(-200);

        Label passwordLabel = new Label("Password");
        passwordLabel.setTranslateY(150);
        passwordLabel.setTranslateX(-200);

        TextField loginTextField = new TextField();
        loginTextField.setMaxSize(300, 30);
        loginTextField.setTranslateY(100);

        PasswordField passwordField = new PasswordField();//password field allows to take a password in a password encrypted form(letters desiplay in form of dots instead of actual letters)
        passwordField.setPromptText("Your password"); // prompt text will appear in empty field, good for short instructions.
        passwordField.setMaxSize(300, 30);
        passwordField.setTranslateY(150);

        Button registerButton = new Button();
        registerButton.setText("Register");
        registerButton.setTranslateX(450);
        registerButton.setTranslateY(300);
        registerButton.setMinSize(100, 50);

        Button signinButton = new Button();
        signinButton.setText("Sign in");
        signinButton.setTranslateY(250);
        signinButton.setMinSize(150, 75);

        //register objects
        Text registerText = new Text();
        registerText.setText("Register to Medley Game");
        registerText.setTranslateY(-300);
        registerText.setFont(Font.font("Verdana", 25));

        TextField registerUsernameField = new TextField();
        registerUsernameField.setPromptText("Your username");
        registerUsernameField.setMaxSize(300, 30);
        registerUsernameField.setTranslateX(-265);
        registerUsernameField.setTranslateY(-220);

        Label registerUsernameLabel = new Label();
        registerUsernameLabel.setText("Username");
        registerUsernameLabel.setTranslateX(-455);
        registerUsernameLabel.setTranslateY(-220);

        PasswordField registerPasswordField = new PasswordField();
        registerPasswordField.setPromptText("Your password");
        registerPasswordField.setMaxSize(300, 30);
        registerPasswordField.setTranslateX(-265);
        registerPasswordField.setTranslateY(-180);

        Label registerPasswordLabel = new Label();
        registerPasswordLabel.setText("Password");
        registerPasswordLabel.setTranslateX(-455);
        registerPasswordLabel.setTranslateY(-180);

        TextField registerEmailField = new TextField();
        registerEmailField.setPromptText("Enter your email for any updates");
        registerEmailField.setMaxSize(500, 30);
        registerEmailField.setTranslateX(-166);
        registerEmailField.setTranslateY(-140);

        Label registerEmailLabel = new Label();
        registerEmailLabel.setText("Email Address");
        registerEmailLabel.setTranslateX(-471);
        registerEmailLabel.setTranslateY(-140);

        final ComboBox GenreComboBox = new ComboBox();
        GenreComboBox.getItems().addAll("RPG", "Shooter", "Card", "Action", "Platform", "Strategy", "Sports");
        GenreComboBox.setTranslateX(-363);
        GenreComboBox.setTranslateY(-100);

        Label registerGenreLabel = new Label();
        registerGenreLabel.setText("Favourite Genre");
        registerGenreLabel.setTranslateX(-480);
        registerGenreLabel.setTranslateY(-100);

        TextField registerGameField = new TextField();
        registerGameField.setPromptText("Enter your favourite game");
        registerGameField.setMaxSize(300, 30);
        registerGameField.setTranslateX(-265);
        registerGameField.setTranslateY(-60);

        Label registerGameLabel = new Label();
        registerGameLabel.setText("Favourite Game");
        registerGameLabel.setTranslateX(-479);
        registerGameLabel.setTranslateY(-60);

        TextField registerCommentField = new TextField();
        registerCommentField.setMaxSize(500, 100);
        registerCommentField.setTranslateX(-166);
        registerCommentField.setTranslateY(30);

        Label registerCommentLabel = new Label();
        registerCommentLabel.setText("Comments");
        registerCommentLabel.setTranslateX(-465);
        registerCommentLabel.setTranslateY(25);

        Button registerRegisterButton = new Button();
        registerRegisterButton.setText("Register");
        registerRegisterButton.setTranslateY(270);
        registerRegisterButton.setMaxSize(300, 100);

        Button registerLoginButton = new Button();
        registerLoginButton.setText("Return to Log in");
        registerLoginButton.setTranslateX(450);
        registerLoginButton.setTranslateY(300);
        registerLoginButton.setMinSize(100, 50);

        //main menu objects
        Text mainMenuText = new Text();
        mainMenuText.setText("Main Menu");
        mainMenuText.setTranslateY(-300);
        mainMenuText.setFont(Font.font("Verdana", 50));

        Text mainMenuWelcome = new Text();
        mainMenuWelcome.setText("Welcome, please choose the game you'd like to play!");
        mainMenuWelcome.setTranslateY(-235);
        mainMenuWelcome.setFont(Font.font("Verdana", 35));

        Button guessTheNumberButton = new Button();
        guessTheNumberButton.setTranslateX(-400);
        guessTheNumberButton.setTranslateY(100);
        guessTheNumberButton.setMinSize(200, 100);
        guessTheNumberButton.setText("Guess the number");

        Button resultsMenuButton = new Button();
        resultsMenuButton.setText("Results");
        resultsMenuButton.setTranslateY(100);
        resultsMenuButton.setMinSize(200, 100);

        //guess Game instruction objects
        Text guessInstructionText1 = new Text();
        guessInstructionText1.setText("Instruction: How to play?");
        guessInstructionText1.setTranslateY(-250);
        guessInstructionText1.setFont(Font.font("Verdana", 50));

        Text guessGameInstructionTitle = new Text();
        guessGameInstructionTitle.setText("Guess The Number Game");
        guessGameInstructionTitle.setTranslateY(-190);
        guessGameInstructionTitle.setFont(Font.font("Verdana", 40));

        Text guessGameInstruction = new Text();
        String gGI = "Guess Game is very simple, you will have to guess a number\nfrom 100 available numbers. 1000 points can be rewarded for a"
                + "\nfirst time guess. with each unsuccessful try points go down\nby 100 points.";
        guessGameInstruction.setText(gGI);
        guessGameInstruction.setTranslateY(50);
        guessGameInstruction.setFont(Font.font("Verdana", 25));

        Button playGuessGame = new Button();
        playGuessGame.setText("Play!");
        playGuessGame.setMinSize(200, 100);
        playGuessGame.setTranslateY(270);

        //guess game objects
        Text guessGameTitle = new Text();
        guessGameTitle.setText("Guess The Number");
        guessGameTitle.setFont(Font.font("Verdana", 60));
        guessGameTitle.setTranslateY(-300);

        Text[] displayNumbers = new Text[100];//creating an array of Text objects to store 100 numbers that will be displayed for the guess

        TextField enterGuess = new TextField();
        enterGuess.setPromptText("Guess here...");
        enterGuess.setTranslateX(-400);
        enterGuess.setTranslateY(280);
        enterGuess.setMaxSize(150, 30);

        Button enterGuessButton = new Button();
        enterGuessButton.setText("Guess");
        enterGuessButton.setTranslateY(270);
        enterGuessButton.setMinSize(200, 100);
        int horizontalSpace = -570;
        int verticalSpace = -200;

        for (int a = 0; a < displayNumbers.length; a++) {
            displayNumbers[a] = new Text("");//creating a empty constructor to populate an index of Text array
            displayNumbers[a].setFont(Font.font("Verdana", 28));//setting size and font of the text
        }
        for (int i = 0; i < displayNumbers.length; i++) {
            String a = Integer.toString(i + 1);//text requires a string so the integer generated within the array has to be converted into string
            displayNumbers[i].setText(a);//populating the indexes

            if (i == 20 || i == 40 || i == 60 || i == 80 || i == 100) {
                verticalSpace += 50;
                horizontalSpace = -570;
            }

            horizontalSpace += 54;
            displayNumbers[i].setTranslateY(verticalSpace);
            displayNumbers[i].setTranslateX(horizontalSpace);
        }

        //after guess game result objects
        Text guessGameResultText = new Text();
        guessGameResultText.setFont(Font.font("Verdana", 50));

        Text guessGameResultText2 = new Text();
        guessGameResultText2.setFont(Font.font("Verdana", 40));
        guessGameResultText2.setTranslateY(100);

        Button backToMainMenuGG = new Button();
        backToMainMenuGG.setText("Back to main menu");
        backToMainMenuGG.setTranslateY(270);
        backToMainMenuGG.setMinSize(200, 100);

        //results menu objects
        Text resultsTitle = new Text("Game Results");
        resultsTitle.setTranslateX(-350);
        resultsTitle.setTranslateY(-325);
        resultsTitle.setFont(Font.font("Verdana", 50));
        resultsTitle.setFill(Color.DARKGREEN);
        ArrayList<Player> top1Result = new ArrayList();
        try {
            top1Result = top1();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MaciejMainProject.class.getName()).log(Level.SEVERE, null, ex);
        }

        String topusername = top1Result.get(0).getUsername();
        int topguess = top1Result.get(0).getGuesses();
        int topscore = top1Result.get(0).getGuessGameScore();

        Text top3 = new Text();
        top3.setText("The Best Results:");
        top3.setFont(Font.font("Verdana", 40));
        top3.setTranslateX(-350);
        top3.setTranslateY(-250);

        Text userTop1 = new Text();
        userTop1.setFont(Font.font("Verdana", 25));
        userTop1.setText("By " + topusername);
        userTop1.setTranslateX(-350);
        userTop1.setTranslateY(-200);

        Text guessTop1 = new Text();
        guessTop1.setFont(Font.font("Verdana", 23));
        guessTop1.setText("With " + topguess + " guesses!");
        guessTop1.setTranslateX(-345);
        guessTop1.setTranslateY(-160);

        Text scoreTop1 = new Text();
        scoreTop1.setText("Scored " + topscore + " points!");
        scoreTop1.setFont(Font.font("Verdana", 23));
        scoreTop1.setTranslateX(-345);
        scoreTop1.setTranslateY(-120);

        Button searchButton = new Button();
        searchButton.setText("Search for User");
        searchButton.setMinSize(200, 100);
        searchButton.setTranslateX(230);
        searchButton.setTranslateY(170);

        Text userSearchText = new Text();
        userSearchText.setText("Search for user top result:");
        userSearchText.setFont(Font.font("Verdana", 40));
        userSearchText.setTranslateX(230);
        userSearchText.setTranslateY(-250);

        TextField userSearchTextField = new TextField();
        userSearchTextField.setPromptText("Enter Username");
        userSearchTextField.setMaxSize(300, 30);
        userSearchTextField.setTranslateX(230);
        userSearchTextField.setTranslateY(90);

        Text userTopSearch = new Text();
        userTopSearch.setFont(Font.font("Verdana", 35));
        userTopSearch.setText("Enter Username and search");
        userTopSearch.setTranslateX(220);
        userTopSearch.setTranslateY(-100);

        Text guessSearch = new Text();
        guessSearch.setFont(Font.font("Verdana", 33));
        guessSearch.setText("Enter Username and search");
        guessSearch.setTranslateX(215);
        guessSearch.setTranslateY(-60);

        Text scoreSearch = new Text();
        scoreSearch.setText("Enter Username and search");
        scoreSearch.setFont(Font.font("Verdana", 33));
        scoreSearch.setTranslateX(215);
        scoreSearch.setTranslateY(-20);

        Button returnToMainMenu = new Button();
        returnToMainMenu.setText("Return to Main Menu");
        returnToMainMenu.setMinSize(200, 100);
        returnToMainMenu.setTranslateX(-340);
        returnToMainMenu.setTranslateY(170);

        searchButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                try {
                    ArrayList<Player> userSearch = new ArrayList();

                    String desired = userSearchTextField.getText();
                    userSearch = playerSearch(desired);
                    searchUsername = userSearch.get(0).getUsername();
                    userTopSearch.setText("By " + searchUsername);

                    searchScore = userSearch.get(0).getGuessGameScore();
                    scoreSearch.setText("Scored " + searchScore + " points!");

                    searchGuess = userSearch.get(0).getGuesses();
                    guessSearch.setText("With " + searchGuess + " guesses!");

                } catch (FileNotFoundException ex) {
                    Logger.getLogger(MaciejMainProject.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

//welcome scene
        StackPane welcomeLayout = new StackPane();
        welcomeLayout.getChildren().add(loginbutton);
        welcomeLayout.getChildren().add(welcometext);
        Scene welcomescene = new Scene(welcomeLayout, 1080, 720);

        //main menu scene
        StackPane mainMenuLayout = new StackPane();
        Scene mainMenuScene = new Scene(mainMenuLayout, 1080, 720);
        mainMenuLayout.getChildren().addAll(mainMenuText, mainMenuWelcome, guessTheNumberButton, resultsMenuButton);

        //Guess game instuction scene
        StackPane guessGameInstructionLayout = new StackPane();
        Scene guessGameInstructionScene = new Scene(guessGameInstructionLayout, 1080, 720);
        guessGameInstructionLayout.getChildren().addAll(guessInstructionText1, guessGameInstructionTitle, guessGameInstruction, playGuessGame);
        guessTheNumberButton.setOnAction(e -> window.setScene(guessGameInstructionScene));

        //Guess Game Scene
        StackPane guessGameLayout = new StackPane();
        Scene guessGameScene = new Scene(guessGameLayout, 1080, 720);
        guessGameLayout.getChildren().addAll(displayNumbers);
        guessGameLayout.getChildren().addAll(guessGameTitle, enterGuess, enterGuessButton);
        playGuessGame.setOnAction(e -> window.setScene(guessGameScene));

        //after guess game scene
        StackPane afterGuessGameLayout = new StackPane();
        Scene afterGuessGameScene = new Scene(afterGuessGameLayout, 1080, 720);
        afterGuessGameLayout.getChildren().addAll(guessGameResultText, guessGameResultText2, backToMainMenuGG);
        backToMainMenuGG.setOnAction(e -> window.setScene(mainMenuScene));

        //login scene
        Text message = new Text("");
        message.setFill(Color.RED);

        message.setTranslateY(150);
        message.setTranslateX(300);

        StackPane loginLayout = new StackPane();
        Scene loginScene = new Scene(loginLayout, 1080, 720);
        loginLayout.getChildren().addAll(loginLabel, loginTextField, loginText2, loginText, passwordField, passwordLabel, registerButton, signinButton, message);
        loginbutton.setOnAction(e -> window.setScene(loginScene));//changes the scene

        //result menu scene
        StackPane resultsMenuLayout = new StackPane();
        Scene resultsMenuScene = new Scene(resultsMenuLayout, 1080, 720);
        resultsMenuLayout.getChildren().addAll(resultsTitle, userTop1, guessTop1, scoreTop1, top3, searchButton, userSearchText, userSearchTextField, userTopSearch, guessSearch, scoreSearch, returnToMainMenu);
        resultsMenuButton.setOnAction(e -> window.setScene(resultsMenuScene));
        returnToMainMenu.setOnAction(e -> window.setScene(mainMenuScene));

        registerRegisterButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override

            public void handle(ActionEvent e) {
                try (BufferedWriter bw = new BufferedWriter(new FileWriter("users.txt", true))) {
                    boolean isRegistered = isAccountExistant(registerUsernameField.getText());

                    if (!isRegistered) {
                        bw.write(registerUsernameField.getText());
                        bw.newLine();
                        bw.write(registerPasswordField.getText());
                        bw.newLine();
                        bw.close();
                        JOptionPane.showMessageDialog(null, "Account created successfully, return to sign in page", "Creation successful!", JOptionPane.INFORMATION_MESSAGE);

                    } else {
                        JOptionPane.showMessageDialog(null, "User already exists!", "User exists!", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (IOException e1) {
                    e1.printStackTrace();
                }

            }
        });

        signinButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                String userName = loginTextField.getText();
                String password = passwordField.getText();
                boolean grantAccess = false;

                File f = new File("users.txt");
                try {
                    Scanner read = new Scanner(f);

                    try {
                        noOfLines = countLines(f); // count how many lines in the file
                    } catch (IOException ex) {
                        Logger.getLogger(MaciejMainProject.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    //loop through every line in the file and check against the user name & password
                    for (int i = 0; i < noOfLines; i++) {
                        if (read.nextLine().equals(userName)) { // if the same user name
                            i++;
                            if (read.nextLine().equals(password)) { // check password
                                grantAccess = true; // if also same, change boolean to true
                                break; // and break the for-loop

                            }
                        }
                    }
                    if (grantAccess) {
                        window.setScene(mainMenuScene);
                        finalUserName = userName;
                        MaciejMainProject.this.n = RandomNumber();

                        enterGuessButton.setOnAction(new EventHandler<ActionEvent>() {
                            @Override
                            public void handle(ActionEvent e) {

                                String guessString = enterGuess.getText();
                                int guess = Integer.parseInt(guessString);
                                final GuessTheNumber guessGameRun = new GuessTheNumber(guess, finalUserName, n);

                                if (guessGameRun.getMarkSide() == 2 && guessGameRun.getReturnVictory() == 0) {
                                    for (int b = 0; b < guess; b++) {
                                        displayNumbers[b].setFill(Color.RED);

                                    }
                                    MaciejMainProject.this.guessGameCount++;

                                }

                                if (guessGameRun.getMarkSide() == 1 && guessGameRun.getReturnVictory() == 0) {
                                    for (int b = 99; b >= guess; b--) {
                                        displayNumbers[b - 1].setFill(Color.RED);
                                        displayNumbers[b].setFill(Color.RED);

                                    }
                                    MaciejMainProject.this.guessGameCount++;

                                }
                                if (guessGameRun.getReturnVictory() == 1 && guessGameRun.getReturnVictory() == 1) {
                                    displayNumbers[guess - 1].setFill(Color.GREEN);

                                    int finalscore = GuessGamePointCount(MaciejMainProject.this.guessGameCount);
                                    String points = Integer.toString(finalscore); //score has to be converted to String to allow Buffer to write to file
                                    try (BufferedWriter bw = new BufferedWriter(new FileWriter("GuessTheNumberScore.txt", true))) {
                                        bw.write(finalUserName);
                                        bw.newLine();
                                        bw.write(MaciejMainProject.this.guessGameCount);
                                        bw.newLine();
                                        bw.write(points);
                                        bw.newLine();
                                        bw.close();
                                    } catch (IOException e1) {
                                        e1.printStackTrace();
                                    }
                                    window.setScene(afterGuessGameScene);
                                    guessGameResultText.setText("You win with: " + MaciejMainProject.this.guessGameCount + " Guesses!");
                                    guessGameResultText2.setText("With a score of: " + finalscore + " points");

                                    for (int b = 0; b < displayNumbers.length; b++) {
                                        displayNumbers[b].setFill(Color.BLACK);
                                    }
                                    MaciejMainProject.this.n = RandomNumber();
                                    guessGameCount = 1;
                                }
                            }
                        });

                    } else {
                        message.setText("Incorrect password or username!");
                    }

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                }
            }
        });

        //register scene
        StackPane registerLayout = new StackPane();
        Scene registerScene = new Scene(registerLayout, 1080, 720);
        registerLayout.getChildren().addAll(registerText, registerUsernameField, registerUsernameLabel, registerPasswordField, registerPasswordLabel, registerEmailField, registerEmailLabel);
        registerLayout.getChildren().addAll(GenreComboBox, registerGenreLabel, registerGameField, registerGameLabel, registerCommentField, registerCommentLabel, registerRegisterButton, registerLoginButton);
        registerButton.setOnAction(e -> window.setScene(registerScene));
        registerLoginButton.setOnAction(e -> window.setScene(loginScene));

        
        
       
        primaryStage.setScene(welcomescene);
        primaryStage.setResizable(false);
        primaryStage.setTitle("Guess The Number Game");
        primaryStage.show();
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    public static int GuessGamePointCount(int score) {

        int maxPoints = 1000;

        score = score * 100;

        int finalscore = maxPoints - score;

        if (finalscore < 0) {
            finalscore = 0;
        }
        return finalscore;
    }

    public static int RandomNumber() {
        Random random = new Random();
        int n = random.nextInt(100 + 1);
        return n;
    }

    public static int countLines(File aFile) throws IOException {
        LineNumberReader reader = null;
        try {
            reader = new LineNumberReader(new FileReader(aFile));
            while ((reader.readLine()) != null);
            return reader.getLineNumber();
        } catch (Exception ex) {
            return -1;
        } finally {
            if (reader != null) {
                reader.close();
            }
        }
    }

    public static ArrayList<Player> top1() throws FileNotFoundException {
        File f = new File("GuessTheNumberScore.txt");
        int noOfLines = 0;
        Scanner read = new Scanner(f);
        ArrayList<Player> arr = new ArrayList<Player>();

        try {
            noOfLines = countLines(f); // count how many lines in the file
        } catch (IOException ex) {
            Logger.getLogger(MaciejMainProject.class.getName()).log(Level.SEVERE, null, ex);
        }
        String username;
        String score;
        int newscore = 0;
        int guesses = 0;
        int highestscore = 0;
        String topusername = "";
        int topguess = 0;
        //loop through every line in the file and check against the user name & password
        for (int i = 0; i < noOfLines / 3; i++) {
            username = read.nextLine();
            read.nextLine();
            score = read.nextLine();
            newscore = Integer.parseInt(score);
            guesses = 1000 - newscore;
            guesses = guesses / 100;

            if (newscore > highestscore) {
                highestscore = newscore;
                topusername = username;
                topguess = guesses;
            }
        }
        arr.add(new Player(topusername, topguess, highestscore));
        return arr;
    }

    public static ArrayList<Player> playerSearch(String x) throws FileNotFoundException {
        File f = new File("GuessTheNumberScore.txt");
        int noOfLines = 0;
        Scanner read = new Scanner(f);
        ArrayList<Player> arr = new ArrayList<Player>();
        String fileUsername = "";
        String score;
        int newscore = 0;
        int guesses = 0;
        boolean arrayNotNull = false;
        try {
            noOfLines = countLines(f); // count how many lines in the file
        } catch (IOException ex) {
            Logger.getLogger(MaciejMainProject.class.getName()).log(Level.SEVERE, null, ex);
        }
        for (int i = 0; i < noOfLines / 3; i++) {
            fileUsername = read.nextLine();
            read.nextLine();
            score = read.nextLine();
            newscore = Integer.parseInt(score);
            guesses = 1000 - newscore;
            guesses = guesses / 100;

            if (fileUsername.equals(x)) {
                arr.add(new Player(fileUsername, guesses, newscore));
                arrayNotNull = true;
            }
        }
        if (!arrayNotNull) {
            arr.add(new Player("Not Found", 0, 0));

        }
        return arr;
    }

    public static boolean isAccountExistant(String x) throws FileNotFoundException {
        File f = new File("GuessTheNumberScore.txt");
        int noOfLines = 0;
        String fileUsername = "";
        boolean fileExists = false;
        Scanner read = new Scanner(f);
        try {
            noOfLines = countLines(f); // count how many lines in the file
        } catch (IOException ex) {
            Logger.getLogger(MaciejMainProject.class.getName()).log(Level.SEVERE, null, ex);
        }
        for (int i = 0; i < noOfLines / 3; i++) {
            fileUsername = read.nextLine();
            read.nextLine();
            read.nextLine();

            if (fileUsername.equals(x)) {
                fileExists = true;
            }

        }
        return fileExists;
    }
}
