/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maciejmainproject;

import java.util.Random;

/**
 *
 * @author macie
 */
public class GuessTheNumber {

    private int markSide = 0;
    private int guess;
    private String username;
    private Player player;
    private int numberToGuess;
    private int returnVictory;
    private int GuessCount;

    public GuessTheNumber(int guess, String username, int numberToGuess) {
        this.guess = guess;
        System.out.println(numberToGuess);
        this.player = new Player("", 0, 0);
        setGuessCount(0);
        player.setUsername(username);
        System.out.println(getGuessCount());
        int i = 10;
        i++;
        System.out.println(i);

        setReturnVictory(0);

        if (guess > numberToGuess) {
            setMarkSide(1);

        }
        if (guess < numberToGuess) {
            setMarkSide(2);
        }

        if (guess == numberToGuess) {
            setReturnVictory(1);
        }

    }

    public int getGuessCount() {
        return GuessCount;
    }

    public void setGuessCount(int GuessCount) {
        this.GuessCount =+ GuessCount;
    }

    public int getReturnVictory() {
        return returnVictory;
    }

    public void setReturnVictory(int returnVictory) {
        this.returnVictory = returnVictory;
    }

 

    public void setMarkSide(int markSide) {
        this.markSide = markSide;
    }

    public void setGuess(int guess) {
        this.guess = guess;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public int getMarkSide() {
        return markSide;
    }

    public int getGuess() {
        return guess;
    }

    public String getUsername() {
        return username;
    }

    public Player getPlayer() {
        return player;
    }

}
