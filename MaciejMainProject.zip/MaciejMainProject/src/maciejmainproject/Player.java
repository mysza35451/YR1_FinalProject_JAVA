/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maciejmainproject;

/**
 *
 * @author macie
 */
public class Player {
    private String username;
    private int guesses;
    private int guessGameScore;

    public Player(String username, int guesses, int guessGameScore) {
        this.username = username;
        this.guesses = guesses;
        this.guessGameScore = guessGameScore;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public int getGuesses() {
        return guesses;
    }

    public int getGuessGameScore() {
        return guessGameScore;
    }



    public void setGamesPlayed(int gamesPlayed) {
        this.guesses = gamesPlayed;
    }

    public void setGuessGameScore(int guessGameScore) {
        this.guessGameScore = guessGameScore;
    }

 


    
    
    
}
